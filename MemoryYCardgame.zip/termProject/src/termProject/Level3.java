package termProject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;


import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.Timer;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Level3 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JMenuItem Exit0;
	private int acIndex, previousAC = -1,tries = 12; //acIndex = actionCommandIndex, AC = action command
	private int gameWinCheck = 1,score = 0;
	private String iconString;
	private List<JButton> buttons;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	
	public Level3(int pre_score) {
		score = pre_score;
		setBackground(new Color(101, 189, 209));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setBounds(100, 100, 649, 777);
		
		
		buttons = new ArrayList<>();
		ArrayList<String> iconNames = new ArrayList<String>();
		ArrayList<Boolean> isOpen = new ArrayList<Boolean>(16); //Checking if the cards are open or not
		isOpen.addAll(Collections.nCopies(16, Boolean.FALSE)); //Initializing all the values as false
		
		
		//ADDING ELEMENTS TO THE ICONNAMES LIST
		//index 0-7
		iconNames.add("0");
		iconNames.add("1");
		iconNames.add("2");
		iconNames.add("3");
		iconNames.add("4");
		iconNames.add("5");
		iconNames.add("6");
		iconNames.add("7");
		
		//index 8-15
		iconNames.add("0");
		iconNames.add("1");
		iconNames.add("2");
		iconNames.add("3");
		iconNames.add("4");
		iconNames.add("5");
		iconNames.add("6");
		iconNames.add("7");
		
		Collections.shuffle(iconNames); //Shuffling the cards
		
		//SETTING MENUS
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu Game = new JMenu("Game");
		menuBar.add(Game);
		
		JMenuItem mnıtmNewMenuItem = new JMenuItem("Restart");

		Game.add(mnıtmNewMenuItem);
		
		JMenuItem mnıtmNewMenuItem_1 = new JMenuItem("High Scores");
		Game.add(mnıtmNewMenuItem_1);
		
		JMenu About = new JMenu("About");
		menuBar.add(About);
		
		JMenuItem mnıtmNewMenuItem_3 = new JMenuItem("About the Developer");
		mnıtmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Name : Başak\n"
						+ "Surname: Sakallı\n"
						+ "Number : 20220702086", "About the Developer", JOptionPane.PLAIN_MESSAGE);
			}
		});
		About.add(mnıtmNewMenuItem_3);
		
		JMenuItem mnıtmNewMenuItem_2 = new JMenuItem("About the Game");
		mnıtmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "This is a memory game with 3 levels\n"
						+ "You need to find matching pictures to win the game\n"
						+ "Don't forget that you have limited guesses.", "About the Game", JOptionPane.PLAIN_MESSAGE);
			}
		});
		About.add(mnıtmNewMenuItem_2);
		
		JMenu Exit = new JMenu("Exit");
		
		menuBar.add(Exit);
		
		Exit0 = new JMenuItem("Exit");
		Exit0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		Exit.add(Exit0);
		

		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(201, 36, 14));
		contentPane.setBorder(new EmptyBorder(10,10,10, 10));
		setContentPane(contentPane);
		
		
		//SETTING THE GAME'S LABELS
		JLabel triesLbl = new JLabel("Tries left : 12");
		triesLbl.setFont(new Font("Arial", Font.BOLD, 30));
		triesLbl.setHorizontalAlignment(SwingConstants.LEFT);
		triesLbl.setForeground(Color.WHITE);
		triesLbl.setBounds(321, 17, 265, 44);
		contentPane.add(triesLbl);
		
		JLabel levelLbl = new JLabel("LEVEL 3");
		levelLbl.setFont(new Font("Arial", Font.BOLD, 30));
		levelLbl.setForeground(new Color(255, 255, 255));
		levelLbl.setBounds(102, 17, 169, 44);
		contentPane.add(levelLbl);
		
		
		//MENU ITEM FOR "RESTARTING"
		mnıtmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i = 0;i<16;i++)
				{
					isOpen.set(i, false);
				}
				
				Collections.shuffle(iconNames);
				
				tries = 18;
				triesLbl.setText("Tries left : "+tries);
				previousAC = -1;
				
				for(JButton clButton : buttons) 
				{
					clButton.setIcon(ImageUtil.loadImage("/pictures3/no.png"));
				}
				
			}
		});
		
		//DECLARING JBUTTONS
		JButton b0 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b0.setBounds(5, 71, 153, 154);
		JButton b1 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b1.setBounds(163, 71, 153, 154);
		JButton b2 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b2.setBounds(321, 71, 153, 154);
		JButton b3 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b3.setBounds(479, 71, 153, 154);
		JButton b4 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b4.setBounds(5, 230, 153, 154);
		JButton b5 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b5.setBounds(163, 230, 153, 154);
		JButton b6 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b6.setBounds(321, 230, 153, 154);
		JButton b7 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b7.setBounds(479, 230, 153, 154);
		JButton b8 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b8.setBounds(5, 389, 153, 154);
		JButton b9 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b9.setBounds(163, 389, 153, 154);
		JButton b10 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b10.setBounds(321, 389, 153, 154);
		JButton b11 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b11.setBounds(479, 389, 153, 154);
		JButton b12 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b12.setBounds(5, 553, 153, 154);
		JButton b13 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b13.setBounds(163, 553, 153, 154);
		JButton b14 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b14.setBounds(321, 553, 153, 154);
		JButton b15 = new JButton(ImageUtil.loadImage("/pictures3/no.png"));
		b15.setBounds(479, 553, 153, 154);
		
		buttons.add(b0);
		buttons.add(b1);
		buttons.add(b2);
		buttons.add(b3);
		buttons.add(b4);
		buttons.add(b5);
		buttons.add(b6);
		buttons.add(b7);
		buttons.add(b8);
		buttons.add(b9);
		buttons.add(b10);
		buttons.add(b11);
		buttons.add(b12);
		buttons.add(b13);
		buttons.add(b14);
		buttons.add(b15);
		
		//SETTING AC'S TO JBUTTONS ACCORDING TO THE INDEX OF BUTTONS
		b0.setActionCommand("0");
		b1.setActionCommand("1");
		b2.setActionCommand("2");
		b3.setActionCommand("3");
		b4.setActionCommand("4");
		b5.setActionCommand("5");
		b6.setActionCommand("6");
		b7.setActionCommand("7");
		b8.setActionCommand("8");
		b9.setActionCommand("9");
		b10.setActionCommand("10");
		b11.setActionCommand("11");
		b12.setActionCommand("12");
		b13.setActionCommand("13");
		b14.setActionCommand("14");
		b15.setActionCommand("15");

		// (OPENING, MATCHING, CLOSING) CODE BLOCK FOR ALL CARDS
		for (JButton currentButton : buttons) {
			currentButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				acIndex = Integer.parseInt(e.getActionCommand());
				//if card is not opened open the picture
				if(!(isOpen.get(acIndex))) 
				{
					isOpen.set(acIndex, true);
					
					//debugging
					System.out.println(acIndex);
					System.out.println(iconNames.get(acIndex));
					
					iconString = iconNames.get(acIndex);
					iconString = "/pictures3/" + iconString +".png";
					System.out.println(iconString);
					currentButton.setIcon(ImageUtil.loadImage(iconString));
					
					

					//let's check if this card is the first pair
					if(previousAC == -1) 
					{
						previousAC = acIndex;
						
					}else //if it is the second card
					{ 
						 
						if(iconNames.get(acIndex) == iconNames.get(previousAC)) //if two pairs are the same
						{
							for(int i =0;i<16;i++) 
							{
								if(!isOpen.get(i)) 
								{
									gameWinCheck = 0;
									break;
								}
							}
							
							if(gameWinCheck == 1) 
							{
								JOptionPane.showMessageDialog(null,"Congrats you won!!","",JOptionPane.INFORMATION_MESSAGE);
								JOptionPane.showMessageDialog(null,"Here is your overal score : " + score,"",JOptionPane.INFORMATION_MESSAGE);
							}else 
							{
								gameWinCheck=1;
							}
							
							System.out.println(tries);
							previousAC = -1;
							
							score = score + 3;
							
						}else //if they're not the same
						{
							score = score -3;
							
							
							
							//Turn the picture's back for the current card
							
							//And close the card
							
							
							
			                for (JButton button : buttons) 
			                {
				            if (Integer.parseInt(button.getActionCommand()) == previousAC) 
				            {
				               //////
				            	
				            					            	
								SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
							        
						            @Override
						            protected void done() {
						                // Schedule the second GUI update after the first one is done
						                Timer timer = new Timer(500, new ActionListener() {
						                    public void actionPerformed(ActionEvent e) {
						                        // Perform the second GUI update
						                    	button.setIcon(ImageUtil.loadImage("/pictures3/no.png"));
						                    	isOpen.set(previousAC, false);
						                    	currentButton.setIcon(ImageUtil.loadImage("/pictures3/no.png"));
						                    	isOpen.set(acIndex, false);
						                    	previousAC = -1;
						                    	
						                    	
						                    	            	
												tries--;
												triesLbl.setText("Tries left : "+tries);
												
												
												if(tries == 0) {
													JOptionPane.showMessageDialog(null, "YOU LOSE!", "GAME STATUS CHANGED", JOptionPane.WARNING_MESSAGE);

													for(int i = 0;i<16;i++){
														isOpen.set(i, false);
													}
													
													
													Collections.shuffle(iconNames);
													
													tries = 18;
													triesLbl.setText("Tries left : "+tries);
													previousAC = -1;
													
													for(JButton clButton : buttons) {
														clButton.setIcon(ImageUtil.loadImage("/pictures3/no.png"));
													}
													
								                    Level1 level1Frame = new Level1();
								                    
								                    level1Frame.setVisible(true);
								                    setVisible(false);
													
												}
												
												
												System.out.println(tries);
						                    	
						                    	
						                    }
						                });
						                timer.setRepeats(false);
						                timer.start();
						            }

									@Override
									protected Void doInBackground() throws Exception {
										// TODO Auto-generated method stub
										return null;
									}
						        };
						        worker.execute();	
				                break;
				            }
				        }	
						}	
					}
					
				}
			}
		});
		 }
		
		
		contentPane.setLayout(null);

		
		//ADDING JBUTTONS TO CONTENTPANE
		contentPane.add(b0);
		contentPane.add(b1);
		contentPane.add(b2);
		contentPane.add(b3);
		contentPane.add(b4);
		contentPane.add(b5);
		contentPane.add(b6);
		contentPane.add(b7);
		contentPane.add(b8);
		contentPane.add(b9);
		contentPane.add(b10);
		contentPane.add(b11);
		contentPane.add(b12);
		contentPane.add(b13);
		contentPane.add(b14);
		contentPane.add(b15);		
	}
}
