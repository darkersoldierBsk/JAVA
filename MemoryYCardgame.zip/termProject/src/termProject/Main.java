package termProject;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String gameLevel = "Level 1"; //declaring gameLevel as level 1 for default case
    
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Main frame = new Main();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public Main() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 715, 431);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setResizable(false);
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        //LABEL FOR GAME NAME
        JLabel lbl = new JLabel();
        lbl.setForeground(new Color(0, 255, 255));
        lbl.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 26));
        lbl.setText("Memory Card Game");
        lbl.setBounds(218,91,249,31);
        contentPane.add(lbl);
        
        //START BUTTON
        JButton startBtn = new JButton("Start Game");
        startBtn.setBackground(new Color(255, 255, 255));
        startBtn.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
  
            		// Open the Level1 frame
                    Level1 level1Frame = new Level1(); 
                    level1Frame.setVisible(true);
                    setVisible(false);
                
            }
        });
        startBtn.setBounds(280, 150, 121, 21);
        contentPane.add(startBtn);
        
        //SELECT LEVEL BUTTON
        JButton selectLvlBtn = new JButton("Select Level");
        selectLvlBtn.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String[] options = {"Level 1", "Level 2", "Level 3"};
                int choice = JOptionPane.showOptionDialog(
                        null,
                        "Select Game Level",
                        "Game Level",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]
                );

                if (choice >= 0 && choice < options.length) 
                {
                    gameLevel = options[choice];
                    System.out.println("Selected game level: " + gameLevel); // For debugging
                
                }
                
                //OPEN THE SELECTED LEVEL
                if(gameLevel.equals("Level 1")) 
                {
                	Level1 level1Frame = new Level1();
                    level1Frame.setVisible(true);
                    setVisible(false);
                
                }else if(gameLevel.equals("Level 2")) 
                {	
                    Level2 level2Frame = new Level2(0);    
                    level2Frame.setVisible(true);
                    setVisible(false);
                    
                }
                else if(gameLevel.equals("Level 3")) 
                {	
                    Level3 level3Frame = new Level3(0);   
                    level3Frame.setVisible(true);
                    setVisible(false);
                    
                }
            }
        });
        selectLvlBtn.setBackground(new Color(255, 255, 255));
        selectLvlBtn.setBounds(280, 195, 121, 21);
        contentPane.add(selectLvlBtn);
        
        //INSTRUCTIONS BUTTON
        JButton instBtn = new JButton("Instructions");
        instBtn.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                JOptionPane.showMessageDialog(instBtn, "Instructions:\n"
                        + "There are 3 levels in this game. It gets gradually harder!\n"
                        + "Match all pairs of cards to win!", "Message", JOptionPane.INFORMATION_MESSAGE);
            
            }
        });
        instBtn.setBackground(new Color(255, 255, 255));
        instBtn.setBounds(280, 240, 121, 21);
        contentPane.add(instBtn);
        
        //EXIT BUTTON
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        exitButton.setBackground(new Color(255, 255, 255));
        exitButton.setBounds(280, 285, 121, 21);
        contentPane.add(exitButton);
        
        //LABEL FOR BACKGROUND
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBackground(new Color(255, 255, 255));
        lblNewLabel.setIcon(new ImageIcon(Main.class.getResource("/bgMain/background.jpg")));
        lblNewLabel.setBounds(0, -105, 911, 600);
        contentPane.add(lblNewLabel);
    }
}
