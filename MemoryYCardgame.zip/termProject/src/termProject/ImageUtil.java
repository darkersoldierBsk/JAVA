package termProject;

import java.net.URL;

import javax.swing.ImageIcon;

public class ImageUtil {
	public static ImageIcon loadImage(String path) {
        URL imgURL = ImageUtil.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
}
