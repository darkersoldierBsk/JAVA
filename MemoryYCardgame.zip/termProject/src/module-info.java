/**
 * 
 */
/**
 * 
 */
module termProject {
	requires java.desktop;
}